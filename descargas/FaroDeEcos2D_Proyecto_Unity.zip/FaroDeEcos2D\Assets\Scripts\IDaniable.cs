/// <summary>
/// Contrato para todo lo que puede recibir daño (Personaje y Enemigo).
/// Permite que un Proyectil o un Enemigo dañen sin conocer la clase concreta.
/// </summary>
public interface IDaniable
{
    void RecibirDanio(int cantidad);
}
