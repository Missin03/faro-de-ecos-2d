using UnityEngine;

/// <summary>
/// Sombra de niebla. Hereda de Entidad: patrulla entre dos puntos (waypoints)
/// y daña a cualquier IDaniable que la toque (excepto a otros enemigos).
/// </summary>
public class Enemigo : Entidad
{
    [Header("Patrulla")]
    [SerializeField] private Transform puntoA;
    [SerializeField] private Transform puntoB;
    [SerializeField] private int danio = 1;

    private Transform destino;

    protected override void Awake()
    {
        base.Awake();
        destino = puntoB;
    }

    private void Update()
    {
        if (puntoA == null || puntoB == null) return;
        Vector2 nueva = Vector2.MoveTowards(transform.position, destino.position, velocidad * Time.deltaTime);
        cuerpo.MovePosition(nueva);
        if (Vector2.Distance(transform.position, destino.position) < 0.05f)
        {
            destino = destino == puntoA ? puntoB : puntoA;
        }
        if (sprite != null) sprite.flipX = destino.position.x < transform.position.x;
    }

    private void OnCollisionEnter2D(Collision2D choque)
    {
        IDaniable objetivo = choque.collider.GetComponent<IDaniable>();
        if (objetivo != null && !(objetivo is Enemigo))
        {
            objetivo.RecibirDanio(danio);
        }
    }

    public override void RecibirDanio(int cantidad)
    {
        if (animador != null) animador.SetTrigger("Golpe");
        base.RecibirDanio(cantidad);
    }

    protected override void Morir()
    {
        Destroy(gameObject, 0.2f);
    }
}
