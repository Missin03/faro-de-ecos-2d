using UnityEngine;

/// <summary>
/// Clase base de los objetos del escenario con los que se interactúa (Puerta, Coleccionable).
/// </summary>
public abstract class Interactuable : MonoBehaviour
{
    [SerializeField] protected string nombreVisible = "Objeto";

    public abstract void Interactuar();
}
