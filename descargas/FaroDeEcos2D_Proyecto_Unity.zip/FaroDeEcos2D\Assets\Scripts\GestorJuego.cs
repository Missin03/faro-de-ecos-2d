using UnityEngine;

/// <summary>
/// Sistema de puntuación (opción A del R4). Lleva el puntaje y avisa a la UI.
/// </summary>
public class GestorJuego : MonoBehaviour
{
    public static GestorJuego Instancia { get; private set; }

    [SerializeField] private GestorUI interfaz;

    private int puntaje;
    private int fragmentosTotales;
    private int fragmentosRecogidos;

    public int Puntaje => puntaje;

    private void Awake()
    {
        Instancia = this;
    }

    private void Start()
    {
        fragmentosTotales = FindObjectsByType<Coleccionable>(FindObjectsSortMode.None).Length;
        if (interfaz != null) interfaz.MostrarPuntaje(puntaje, fragmentosRecogidos, fragmentosTotales);
    }

    public void SumarPuntos(int puntos)
    {
        puntaje += puntos;
        fragmentosRecogidos++;
        if (interfaz != null)
        {
            interfaz.MostrarPuntaje(puntaje, fragmentosRecogidos, fragmentosTotales);
            if (fragmentosRecogidos >= fragmentosTotales)
            {
                interfaz.MostrarMensaje("¡Recuperaste toda la luz del faro!");
            }
        }
    }
}
