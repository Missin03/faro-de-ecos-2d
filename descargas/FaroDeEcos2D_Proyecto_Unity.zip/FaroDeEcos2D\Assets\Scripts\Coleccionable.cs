using UnityEngine;

/// <summary>
/// Fragmento de luz. Cuando Nara lo toca suma puntos, dispara un efecto visual (Particle System)
/// y un efecto de sonido, y desaparece.
/// </summary>
[RequireComponent(typeof(Collider2D))]
public class Coleccionable : Interactuable
{
    [SerializeField] private int valor = 10;
    [SerializeField] private ParticleSystem prefabEfecto;
    [SerializeField] private AudioClip sonidoRecoger;

    private bool recogido;

    private void OnTriggerEnter2D(Collider2D otro)
    {
        if (!recogido && otro.GetComponent<Personaje>() != null)
        {
            Interactuar();
        }
    }

    public override void Interactuar()
    {
        recogido = true;
        if (GestorJuego.Instancia != null) GestorJuego.Instancia.SumarPuntos(valor);
        if (prefabEfecto != null)
        {
            ParticleSystem efecto = Instantiate(prefabEfecto, transform.position, Quaternion.identity);
            efecto.Play();
            Destroy(efecto.gameObject, 2f);
        }
        if (sonidoRecoger != null)
        {
            AudioSource.PlayClipAtPoint(sonidoRecoger, Camera.main.transform.position, 1f);
        }
        Debug.Log($"[Mecánica] {nombreVisible} recogido: +{valor} puntos");
        Destroy(gameObject);
    }
}
