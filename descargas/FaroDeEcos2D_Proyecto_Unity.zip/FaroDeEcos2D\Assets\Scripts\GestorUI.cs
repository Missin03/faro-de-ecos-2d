using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>
/// Interfaz: botón "Abrir compuerta" (TextMesh Pro) y texto de puntaje.
/// El botón se conecta en el Inspector (OnClick -> Puerta.Interactuar) y además por código con AddListener
/// para actualizar su etiqueta.
/// </summary>
public class GestorUI : MonoBehaviour
{
    [SerializeField] private Button botonPuerta;
    [SerializeField] private TMP_Text textoBoton;
    [SerializeField] private TMP_Text textoPuntaje;
    [SerializeField] private TMP_Text textoMensaje;
    [SerializeField] private Puerta puerta;

    private void Start()
    {
        if (botonPuerta != null) botonPuerta.onClick.AddListener(ActualizarEtiqueta);
        if (textoMensaje != null) textoMensaje.text = string.Empty;
    }

    private void ActualizarEtiqueta()
    {
        if (textoBoton != null && puerta != null)
        {
            textoBoton.text = puerta.EstaAbierta ? "Cerrar compuerta" : "Abrir compuerta";
        }
        // Quita el foco del botón para que la barra espaciadora (salto) no lo vuelva a activar.
        if (EventSystem.current != null) EventSystem.current.SetSelectedGameObject(null);
    }

    public void MostrarPuntaje(int puntaje, int recogidos, int total)
    {
        if (textoPuntaje != null) textoPuntaje.text = $"Luz: {puntaje}  ({recogidos}/{total})";
    }

    public void MostrarMensaje(string mensaje)
    {
        if (textoMensaje != null) textoMensaje.text = mensaje;
    }
}
