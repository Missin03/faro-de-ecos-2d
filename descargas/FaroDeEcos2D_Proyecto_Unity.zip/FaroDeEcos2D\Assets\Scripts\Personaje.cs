using UnityEngine;

/// <summary>
/// Nara, la protagonista. Hereda de Entidad: se mueve, salta y lanza destellos.
/// Actualiza los parámetros del Animator (Velocidad y EnSuelo).
/// </summary>
[RequireComponent(typeof(AudioSource))]
public class Personaje : Entidad
{
    [Header("Movimiento")]
    [SerializeField] private float fuerzaSalto = 12f;
    [SerializeField] private Transform detectorSuelo;
    [SerializeField] private float radioSuelo = 0.15f;
    [SerializeField] private LayerMask capaSuelo;

    [Header("Ataque")]
    [SerializeField] private Proyectil prefabDestello;
    [SerializeField] private Transform puntoDisparo;

    [Header("Sonidos")]
    [SerializeField] private AudioClip sonidoSalto;
    [SerializeField] private AudioClip sonidoDanio;

    private AudioSource audioFuente;
    private Vector3 puntoInicio;
    private bool enSuelo;
    private int direccion = 1;

    protected override void Awake()
    {
        base.Awake();
        audioFuente = GetComponent<AudioSource>();
        puntoInicio = transform.position;
    }

    private void Update()
    {
        float h = Input.GetAxisRaw("Horizontal");
        Mover(h);

        enSuelo = detectorSuelo != null &&
                  Physics2D.OverlapCircle(detectorSuelo.position, radioSuelo, capaSuelo) != null;

        if (Input.GetButtonDown("Jump") && enSuelo)
        {
            Saltar();
        }

        if (Input.GetKeyDown(KeyCode.F))
        {
            Atacar();
        }

        if (animador != null)
        {
            animador.SetFloat("Velocidad", Mathf.Abs(h));
            animador.SetBool("EnSuelo", enSuelo);
        }

        if (transform.position.y < -8f)
        {
            Morir();
        }
    }

    public void Mover(float h)
    {
        cuerpo.linearVelocity = new Vector2(h * velocidad, cuerpo.linearVelocity.y);
        if (h != 0)
        {
            direccion = h > 0 ? 1 : -1;
            sprite.flipX = direccion < 0;
        }
    }

    public void Saltar()
    {
        cuerpo.linearVelocity = new Vector2(cuerpo.linearVelocity.x, fuerzaSalto);
        if (sonidoSalto != null) audioFuente.PlayOneShot(sonidoSalto);
    }

    public void Atacar()
    {
        if (prefabDestello == null || puntoDisparo == null) return;
        Proyectil p = Instantiate(prefabDestello, puntoDisparo.position, Quaternion.identity);
        p.Lanzar(direccion, gameObject);
    }

    public override void RecibirDanio(int cantidad)
    {
        if (sonidoDanio != null) audioFuente.PlayOneShot(sonidoDanio);
        base.RecibirDanio(cantidad);
    }

    protected override void Morir()
    {
        // Reaparece en el punto de inicio con la salud completa.
        transform.position = puntoInicio;
        cuerpo.linearVelocity = Vector2.zero;
        salud = saludMaxima;
    }
}
