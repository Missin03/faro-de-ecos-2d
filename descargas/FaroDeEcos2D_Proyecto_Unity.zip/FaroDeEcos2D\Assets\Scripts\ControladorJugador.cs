using UnityEngine;

public class ControladorJugador : MonoBehaviour
{
    public float velocidad = 5f;

    void Update()
    {
        float movimiento = Input.GetAxis("Horizontal");
        transform.Translate(movimiento * velocidad * Time.deltaTime, 0, 0);
    }
}
