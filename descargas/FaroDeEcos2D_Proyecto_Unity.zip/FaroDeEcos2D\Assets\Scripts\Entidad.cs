using UnityEngine;

/// <summary>
/// Clase base abstracta de los seres vivos del juego (Personaje y Enemigo).
/// Concentra salud, velocidad y las referencias a componentes comunes.
/// </summary>
[RequireComponent(typeof(Rigidbody2D))]
public abstract class Entidad : MonoBehaviour, IDaniable
{
    [Header("Atributos de la entidad")]
    [SerializeField] protected int saludMaxima = 3;
    [SerializeField] protected float velocidad = 3f;

    protected int salud;
    protected Rigidbody2D cuerpo;
    protected Animator animador;
    protected SpriteRenderer sprite;

    public int Salud => salud;

    protected virtual void Awake()
    {
        salud = saludMaxima;
        cuerpo = GetComponent<Rigidbody2D>();
        animador = GetComponent<Animator>();
        sprite = GetComponent<SpriteRenderer>();
    }

    public virtual void RecibirDanio(int cantidad)
    {
        salud = Mathf.Max(0, salud - cantidad);
        if (salud == 0)
        {
            Morir();
        }
    }

    /// <summary>Cada subclase decide qué pasa al quedarse sin salud.</summary>
    protected abstract void Morir();
}
