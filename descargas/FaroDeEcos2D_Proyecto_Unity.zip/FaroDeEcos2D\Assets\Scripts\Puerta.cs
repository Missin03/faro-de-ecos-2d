using UnityEngine;

/// <summary>
/// Compuerta del faro. Al interactuar cambia el parámetro "Abierta" del Animator.
/// La animación Door_Open llama al Animation Event AlTerminarApertura en su último cuadro.
/// </summary>
[RequireComponent(typeof(Animator), typeof(AudioSource))]
public class Puerta : Interactuable
{
    [SerializeField] private Collider2D colisionBloqueo;
    [SerializeField] private AudioClip sonidoApertura;

    private Animator animador;
    private AudioSource audioFuente;
    private bool abierta;

    public bool EstaAbierta => abierta;

    private void Awake()
    {
        animador = GetComponent<Animator>();
        audioFuente = GetComponent<AudioSource>();
    }

    public override void Interactuar()
    {
        if (abierta) Cerrar(); else Abrir();
    }

    public void Abrir()
    {
        abierta = true;
        animador.SetBool("Abierta", true);
        Debug.Log($"[UI -> Script] {nombreVisible}: parámetro Abierta = true");
    }

    public void Cerrar()
    {
        abierta = false;
        animador.SetBool("Abierta", false);
        if (colisionBloqueo != null) colisionBloqueo.enabled = true;
        Debug.Log($"[UI -> Script] {nombreVisible}: parámetro Abierta = false");
    }

    // Animation Event: se ejecuta en el último cuadro del clip Door_Open.
    public void AlTerminarApertura()
    {
        if (sonidoApertura != null) audioFuente.PlayOneShot(sonidoApertura);
        if (colisionBloqueo != null) colisionBloqueo.enabled = false;
        Debug.Log($"[Animation Event] {nombreVisible}: apertura terminada, sonido y paso habilitado");
    }
}
