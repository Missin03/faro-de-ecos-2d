#if UNITY_EDITOR
using System.Collections.Generic;
using System.IO;
using System.Linq;
using TMPro;
using UnityEditor;
using UnityEditor.Animations;
using UnityEditor.Events;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

/// <summary>
/// Arma el proyecto «Faro de Ecos 2D» de forma reproducible:
/// importación de recursos, clips, Animator Controllers, prefabs, escenas y builds.
/// Se ejecuta con -executeMethod ConstructorFaro.Paso1_Preparar / Paso2_Contenido / BuildWebGL / BuildWindows.
/// </summary>
public static class ConstructorFaro
{
    const string SPR = "Assets/Sprites";
    const string AUD = "Assets/Sounds";
    const string ANI = "Assets/Animations";
    const string PRE = "Assets/Prefabs";
    const string ESC = "Assets/Scenes";
    const string MAT = "Assets/Materials";
    const int PPU = 64;
    const int CAPA_SUELO = 8;

    // ---------------------------------------------------------------- Paso 1
    [MenuItem("Faro de Ecos/1. Preparar proyecto")]
    public static void Paso1_Preparar()
    {
        foreach (var d in new[] { SPR, AUD, ANI, PRE, ESC, MAT, "Assets/Scripts", "Assets/UI" })
            if (!AssetDatabase.IsValidFolder(d)) Directory.CreateDirectory(d);
        AssetDatabase.Refresh();

        EditorSettings.defaultBehaviorMode = EditorBehaviorMode.Mode2D;
        PlayerSettings.companyName = "Emmanuel Missin Garcia Vargas";
        PlayerSettings.productName = "Faro de Ecos 2D";

        // Capa «Suelo»
        var tagManager = new SerializedObject(AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/TagManager.asset")[0]);
        var capas = tagManager.FindProperty("layers");
        capas.GetArrayElementAtIndex(CAPA_SUELO).stringValue = "Suelo";
        tagManager.ApplyModifiedProperties();

        // Recursos esenciales de TextMesh Pro
        var ugui = UnityEditor.PackageManager.PackageInfo.FindForAssetPath("Packages/com.unity.ugui");
        string tmp = ugui != null ? Path.Combine(ugui.resolvedPath, "Package Resources", "TMP Essential Resources.unitypackage") : "";
        Debug.Log("[ConstructorFaro] TMP: " + tmp + " existe=" + File.Exists(tmp));
        if (File.Exists(tmp) && !AssetDatabase.IsValidFolder("Assets/TextMesh Pro"))
            AssetDatabase.ImportPackage(tmp, false);

        ConfigurarImportacion();
        AssetDatabase.SaveAssets();
        Debug.Log("[ConstructorFaro] Paso 1 listo");
    }

    static void ConfigurarImportacion()
    {
        foreach (string guid in AssetDatabase.FindAssets("t:Texture2D", new[] { SPR }))
        {
            string ruta = AssetDatabase.GUIDToAssetPath(guid);
            var imp = (TextureImporter)AssetImporter.GetAtPath(ruta);
            imp.textureType = TextureImporterType.Sprite;
            imp.spriteImportMode = SpriteImportMode.Single;
            imp.spritePixelsPerUnit = ruta.EndsWith("fondo_isla.png") ? 50 : PPU;
            imp.filterMode = ruta.EndsWith("fondo_isla.png") ? FilterMode.Bilinear : FilterMode.Point;
            imp.textureCompression = TextureImporterCompression.Uncompressed;
            imp.mipmapEnabled = false;
            imp.SaveAndReimport();
        }
    }

    // ---------------------------------------------------------------- Paso 2
    [MenuItem("Faro de Ecos/2. Crear contenido")]
    public static void Paso2_Contenido()
    {
        ConfigurarImportacion();
        var clips = CrearClips();
        var ctrl = CrearControllers(clips);
        var prefabs = CrearPrefabs(ctrl);
        CrearEscenaR1();
        CrearEscenaR2(clips);
        CrearNivel(ESC + "/R3_Faro.unity", prefabs, 2);
        CrearNivel(ESC + "/Nivel_01.unity", prefabs, 5);
        EditorBuildSettings.scenes = new[]
        {
            new EditorBuildSettingsScene(ESC + "/Nivel_01.unity", true),
        };
        AssetDatabase.SaveAssets();
        Debug.Log("[ConstructorFaro] Paso 2 listo");
    }

    static Sprite S(string nombre) => AssetDatabase.LoadAssetAtPath<Sprite>($"{SPR}/{nombre}.png");
    static AudioClip A(string nombre) => AssetDatabase.LoadAssetAtPath<AudioClip>($"{AUD}/{nombre}.wav");

    static AnimationClip Clip(string nombre, string[] cuadros, float fps, bool bucle)
    {
        var clip = new AnimationClip { frameRate = fps };
        var binding = EditorCurveBinding.PPtrCurve("", typeof(SpriteRenderer), "m_Sprite");
        var llaves = new List<ObjectReferenceKeyframe>();
        for (int i = 0; i < cuadros.Length; i++)
            llaves.Add(new ObjectReferenceKeyframe { time = i / fps, value = S(cuadros[i]) });
        if (bucle) llaves.Add(new ObjectReferenceKeyframe { time = cuadros.Length / fps, value = S(cuadros[0]) });
        AnimationUtility.SetObjectReferenceCurve(clip, binding, llaves.ToArray());
        var cfg = AnimationUtility.GetAnimationClipSettings(clip);
        cfg.loopTime = bucle;
        AnimationUtility.SetAnimationClipSettings(clip, cfg);
        string ruta = $"{ANI}/{nombre}.anim";
        AssetDatabase.DeleteAsset(ruta);
        AssetDatabase.CreateAsset(clip, ruta);
        return clip;
    }

    static Dictionary<string, AnimationClip> CrearClips()
    {
        var c = new Dictionary<string, AnimationClip>();
        c["Player_Idle"] = Clip("Player_Idle", new[] { "nara_idle_0", "nara_idle_1" }, 3, true);
        c["Player_Run"] = Clip("Player_Run", new[] { "nara_run_0", "nara_run_1", "nara_run_2", "nara_run_3" }, 10, true);
        c["Enemy_Float"] = Clip("Enemy_Float", new[] { "sombra_niebla_0", "sombra_niebla_1" }, 4, true);
        c["Enemy_Hit"] = Clip("Enemy_Hit", new[] { "sombra_niebla_1", "sombra_niebla_0", "sombra_niebla_1" }, 12, false);
        c["Shard_Spin"] = Clip("Shard_Spin", Enumerable.Range(0, 8).Select(i => $"fragmento_luz_{i}").ToArray(), 10, true);
        c["Door_Closed"] = Clip("Door_Closed", new[] { "compuerta_0" }, 1, false);
        c["Door_Open"] = Clip("Door_Open", new[] { "compuerta_0", "compuerta_1", "compuerta_2", "compuerta_3" }, 6, false);
        c["Door_Opened"] = Clip("Door_Opened", new[] { "compuerta_3" }, 1, false);
        c["Door_Close"] = Clip("Door_Close", new[] { "compuerta_3", "compuerta_2", "compuerta_1", "compuerta_0" }, 6, false);

        // Animation Event en el último cuadro de Door_Open
        var evento = new AnimationEvent { functionName = "AlTerminarApertura", time = 3f / 6f };
        AnimationUtility.SetAnimationEvents(c["Door_Open"], new[] { evento });
        EditorUtility.SetDirty(c["Door_Open"]);

        // Animación simple de rotación para el R2 (haz del faro)
        var giro = new AnimationClip { frameRate = 30 };
        giro.SetCurve("", typeof(Transform), "localEulerAnglesRaw.z", AnimationCurve.Linear(0, 0, 4, 360));
        var gcfg = AnimationUtility.GetAnimationClipSettings(giro);
        gcfg.loopTime = true;
        AnimationUtility.SetAnimationClipSettings(giro, gcfg);
        AssetDatabase.DeleteAsset($"{ANI}/Luz_Girar.anim");
        AssetDatabase.CreateAsset(giro, $"{ANI}/Luz_Girar.anim");
        c["Luz_Girar"] = giro;
        return c;
    }

    static AnimatorController NuevoController(string nombre)
    {
        string ruta = $"{ANI}/{nombre}.controller";
        AssetDatabase.DeleteAsset(ruta);
        return AnimatorController.CreateAnimatorControllerAtPath(ruta);
    }

    static AnimatorStateTransition Transicion(AnimatorState de, AnimatorState a, bool salida)
    {
        var t = de.AddTransition(a);
        t.hasExitTime = salida;
        t.exitTime = salida ? 1f : 0f;
        t.duration = 0f;
        return t;
    }

    static Dictionary<string, AnimatorController> CrearControllers(Dictionary<string, AnimationClip> c)
    {
        var r = new Dictionary<string, AnimatorController>();

        var jugador = NuevoController("Player");
        jugador.AddParameter("Velocidad", AnimatorControllerParameterType.Float);
        jugador.AddParameter("EnSuelo", AnimatorControllerParameterType.Bool);
        var sm = jugador.layers[0].stateMachine;
        var idle = sm.AddState("Idle"); idle.motion = c["Player_Idle"];
        var run = sm.AddState("Run"); run.motion = c["Player_Run"];
        sm.defaultState = idle;
        Transicion(idle, run, false).AddCondition(AnimatorConditionMode.Greater, 0.1f, "Velocidad");
        Transicion(run, idle, false).AddCondition(AnimatorConditionMode.Less, 0.1f, "Velocidad");
        r["Player"] = jugador;

        var enemigo = NuevoController("Enemy");
        enemigo.AddParameter("Golpe", AnimatorControllerParameterType.Trigger);
        sm = enemigo.layers[0].stateMachine;
        var flotar = sm.AddState("Float"); flotar.motion = c["Enemy_Float"];
        var golpe = sm.AddState("Hit"); golpe.motion = c["Enemy_Hit"];
        sm.defaultState = flotar;
        Transicion(flotar, golpe, false).AddCondition(AnimatorConditionMode.If, 0, "Golpe");
        Transicion(golpe, flotar, true);
        r["Enemy"] = enemigo;

        var puerta = NuevoController("Door");
        puerta.AddParameter("Abierta", AnimatorControllerParameterType.Bool);
        sm = puerta.layers[0].stateMachine;
        var cerrada = sm.AddState("Closed"); cerrada.motion = c["Door_Closed"];
        var abriendo = sm.AddState("Door_Open"); abriendo.motion = c["Door_Open"];
        var abierta = sm.AddState("Opened"); abierta.motion = c["Door_Opened"];
        var cerrando = sm.AddState("Door_Close"); cerrando.motion = c["Door_Close"];
        sm.defaultState = cerrada;
        Transicion(cerrada, abriendo, false).AddCondition(AnimatorConditionMode.If, 0, "Abierta");
        Transicion(abriendo, abierta, true);
        Transicion(abierta, cerrando, false).AddCondition(AnimatorConditionMode.IfNot, 0, "Abierta");
        Transicion(cerrando, cerrada, true);
        r["Door"] = puerta;

        var frag = NuevoController("Shard");
        frag.layers[0].stateMachine.AddState("Spin").motion = c["Shard_Spin"];
        r["Shard"] = frag;

        var luz = NuevoController("Luz");
        luz.layers[0].stateMachine.AddState("Girar").motion = c["Luz_Girar"];
        r["Luz"] = luz;
        return r;
    }

    static GameObject Sprite(string nombre, string sprite, int orden = 0)
    {
        var go = new GameObject(nombre);
        var sr = go.AddComponent<SpriteRenderer>();
        sr.sprite = S(sprite);
        sr.sortingOrder = orden;
        return go;
    }

    static void Set(Object o, string campo, object valor)
    {
        var so = new SerializedObject(o);
        var p = so.FindProperty(campo);
        switch (valor)
        {
            case Object obj: p.objectReferenceValue = obj; break;
            case int i when p.propertyType == SerializedPropertyType.LayerMask: p.intValue = i; break;
            case int i: p.intValue = i; break;
            case float f: p.floatValue = f; break;
            case string s: p.stringValue = s; break;
        }
        so.ApplyModifiedPropertiesWithoutUndo();
    }

    static GameObject GuardarPrefab(GameObject go)
    {
        string ruta = $"{PRE}/{go.name}.prefab";
        var p = PrefabUtility.SaveAsPrefabAsset(go, ruta);
        Object.DestroyImmediate(go);
        return p;
    }

    static Dictionary<string, GameObject> CrearPrefabs(Dictionary<string, AnimatorController> ctrl)
    {
        var p = new Dictionary<string, GameObject>();

        // Material de partículas
        var sh0 = Shader.Find("Legacy Shaders/Particles/Additive") ?? Shader.Find("Sprites/Default");
        var mat = new Material(sh0) { mainTexture = S("particula").texture };
        AssetDatabase.DeleteAsset($"{MAT}/Particula.mat");
        AssetDatabase.CreateAsset(mat, $"{MAT}/Particula.mat");

        // VFX: estallido de destellos
        var vfx = new GameObject("VFX_Destellos");
        var ps = vfx.AddComponent<ParticleSystem>();
        ps.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
        var main = ps.main;
        main.duration = 0.6f; main.loop = false; main.playOnAwake = true;
        main.startLifetime = new ParticleSystem.MinMaxCurve(0.4f, 0.8f);
        main.startSpeed = new ParticleSystem.MinMaxCurve(2f, 4.5f);
        main.startSize = new ParticleSystem.MinMaxCurve(0.15f, 0.32f);
        main.startColor = new ParticleSystem.MinMaxGradient(new Color(1f, 0.84f, 0.4f), new Color(1f, 0.97f, 0.8f));
        main.gravityModifier = 0.4f;
        var em = ps.emission; em.rateOverTime = 0; em.SetBursts(new[] { new ParticleSystem.Burst(0f, 24) });
        var sh = ps.shape; sh.shapeType = ParticleSystemShapeType.Circle; sh.radius = 0.2f;
        var col = ps.colorOverLifetime; col.enabled = true;
        var grad = new Gradient();
        grad.SetKeys(new[] { new GradientColorKey(Color.white, 0), new GradientColorKey(Color.white, 1) },
                     new[] { new GradientAlphaKey(1, 0), new GradientAlphaKey(1, 0.6f), new GradientAlphaKey(0, 1) });
        col.color = grad;
        var rend = vfx.GetComponent<ParticleSystemRenderer>();
        rend.sharedMaterial = mat; rend.sortingOrder = 20;
        p["VFX_Destellos"] = GuardarPrefab(vfx);

        // Proyectil (destello)
        var des = Sprite("Destello", "destello", 15);
        var rbd = des.AddComponent<Rigidbody2D>(); rbd.gravityScale = 0; rbd.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
        var ccd = des.AddComponent<CircleCollider2D>(); ccd.isTrigger = true; ccd.radius = 0.15f;
        des.AddComponent<Proyectil>();
        p["Destello"] = GuardarPrefab(des);

        // Personaje (Nara)
        var nara = Sprite("Nara", "nara_idle_0", 10);
        var rb = nara.AddComponent<Rigidbody2D>(); rb.freezeRotation = true; rb.gravityScale = 2.5f;
        rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous; rb.interpolation = RigidbodyInterpolation2D.Interpolate;
        var cap = nara.AddComponent<CapsuleCollider2D>(); cap.size = new Vector2(0.55f, 1.35f); cap.offset = new Vector2(0, -0.05f);
        nara.AddComponent<Animator>().runtimeAnimatorController = ctrl["Player"];
        nara.AddComponent<AudioSource>().playOnAwake = false;
        var pie = new GameObject("DetectorSuelo"); pie.transform.SetParent(nara.transform); pie.transform.localPosition = new Vector3(0, -0.75f, 0);
        var mano = new GameObject("PuntoDisparo"); mano.transform.SetParent(nara.transform); mano.transform.localPosition = new Vector3(0.45f, 0.05f, 0);
        var per = nara.AddComponent<Personaje>();
        Set(per, "velocidad", 5f);
        Set(per, "fuerzaSalto", 12f);
        Set(per, "saludMaxima", 3);
        Set(per, "detectorSuelo", pie.transform);
        Set(per, "capaSuelo", 1 << CAPA_SUELO);
        Set(per, "prefabDestello", p["Destello"].GetComponent<Proyectil>());
        Set(per, "puntoDisparo", mano.transform);
        Set(per, "sonidoSalto", A("sfx_salto"));
        Set(per, "sonidoDanio", A("sfx_dano"));
        p["Nara"] = GuardarPrefab(nara);

        // Enemigo (sombra de niebla)
        var som = Sprite("SombraNiebla", "sombra_niebla_0", 9);
        var rbs = som.AddComponent<Rigidbody2D>(); rbs.bodyType = RigidbodyType2D.Kinematic; rbs.useFullKinematicContacts = true;
        som.AddComponent<CircleCollider2D>().radius = 0.45f;
        som.AddComponent<Animator>().runtimeAnimatorController = ctrl["Enemy"];
        var ene = som.AddComponent<Enemigo>();
        Set(ene, "velocidad", 1.5f);
        Set(ene, "saludMaxima", 2);
        p["SombraNiebla"] = GuardarPrefab(som);

        // Puerta (compuerta del faro)
        var pu = Sprite("CompuertaFaro", "compuerta_0", 5);
        var bloq = pu.AddComponent<BoxCollider2D>(); bloq.size = new Vector2(1f, 1.5f);
        pu.AddComponent<Animator>().runtimeAnimatorController = ctrl["Door"];
        pu.AddComponent<AudioSource>().playOnAwake = false;
        var pue = pu.AddComponent<Puerta>();
        Set(pue, "nombreVisible", "Compuerta del faro");
        Set(pue, "colisionBloqueo", bloq);
        Set(pue, "sonidoApertura", A("sfx_compuerta"));
        p["CompuertaFaro"] = GuardarPrefab(pu);

        // Coleccionable (fragmento de luz)
        var fr = Sprite("FragmentoLuz", "fragmento_luz_0", 8);
        var cc = fr.AddComponent<CircleCollider2D>(); cc.isTrigger = true; cc.radius = 0.3f;
        fr.AddComponent<Animator>().runtimeAnimatorController = ctrl["Shard"];
        var col2 = fr.AddComponent<Coleccionable>();
        Set(col2, "nombreVisible", "Fragmento de luz");
        Set(col2, "valor", 10);
        Set(col2, "prefabEfecto", p["VFX_Destellos"].GetComponent<ParticleSystem>());
        Set(col2, "sonidoRecoger", A("sfx_recoger"));
        p["FragmentoLuz"] = GuardarPrefab(fr);

        // Plataforma
        var pl = Sprite("Plataforma", "plataforma_roca", 2);
        pl.layer = CAPA_SUELO;
        pl.AddComponent<BoxCollider2D>();
        p["Plataforma"] = GuardarPrefab(pl);
        return p;
    }

    // ---------------------------------------------------------------- Escenas
    static Camera Camara2D()
    {
        var cam = new GameObject("Main Camera");
        cam.tag = "MainCamera";
        var c = cam.AddComponent<Camera>();
        c.orthographic = true; c.orthographicSize = 5.4f;
        c.clearFlags = CameraClearFlags.SolidColor; c.backgroundColor = new Color(0.07f, 0.1f, 0.21f);
        cam.transform.position = new Vector3(0, 0, -10);
        cam.AddComponent<AudioListener>();
        return c;
    }

    static GameObject Grupo(string nombre)
    {
        return new GameObject(nombre);
    }

    static void CrearEscenaR1()
    {
        var esc = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        Camara2D();
        EditorSceneManager.SaveScene(esc, ESC + "/R1_EscenaVacia.unity");
    }

    static void CrearEscenaR2(Dictionary<string, AnimationClip> clips)
    {
        var esc = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        var gEsc = Grupo("Escenario");
        var gPer = Grupo("Personajes");
        var gAud = Grupo("Audio");
        Camara2D().transform.SetParent(gEsc.transform);

        var fondo = Sprite("Fondo", "fondo_isla", -10); fondo.transform.SetParent(gEsc.transform);
        fondo.transform.position = new Vector3(0, 0, 0);
        var suelo = Sprite("Muelle", "plataforma_roca", 1); suelo.transform.SetParent(gEsc.transform);
        suelo.transform.position = new Vector3(-2, -3.4f, 0); suelo.transform.localScale = new Vector3(6, 1, 1);

        var haz = Sprite("HazDelFaro", "destello", 3); haz.transform.SetParent(gEsc.transform);
        haz.transform.position = new Vector3(5.4f, 2.55f, 0); haz.transform.localScale = new Vector3(5f, 0.6f, 1f);
        var animHaz = haz.AddComponent<Animator>();
        animHaz.runtimeAnimatorController = AssetDatabase.LoadAssetAtPath<RuntimeAnimatorController>($"{ANI}/Luz.controller");

        var nara = Sprite("Nara", "nara_idle_0", 10); nara.transform.SetParent(gPer.transform);
        nara.transform.position = new Vector3(-4, -2.4f, 0);
        nara.AddComponent<ControladorJugador>();

        var musica = new GameObject("MusicaAmbiente"); musica.transform.SetParent(gAud.transform);
        var au = musica.AddComponent<AudioSource>(); au.clip = A("musica_olas_loop"); au.loop = true; au.playOnAwake = true; au.volume = 0.6f;

        EditorSceneManager.SaveScene(esc, ESC + "/R2_Importacion.unity");
    }

    static TMP_Text Texto(Transform padre, string nombre, string texto, Vector2 anclaje, Vector2 pos, int tam, TextAlignmentOptions al)
    {
        var go = new GameObject(nombre, typeof(RectTransform));
        go.transform.SetParent(padre, false);
        var t = go.AddComponent<TextMeshProUGUI>();
        t.text = texto; t.fontSize = tam; t.alignment = al; t.color = Color.white;
        var rt = (RectTransform)go.transform;
        rt.anchorMin = rt.anchorMax = anclaje; rt.pivot = anclaje; rt.anchoredPosition = pos; rt.sizeDelta = new Vector2(900, 80);
        return t;
    }

    static void CrearNivel(string ruta, Dictionary<string, GameObject> p, int fragmentos)
    {
        var esc = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        var gEsc = Grupo("Escenario");
        var gEnt = Grupo("Entidades");
        var gObj = Grupo("Objetos");
        var gSis = Grupo("Sistemas");
        Camara2D().transform.SetParent(gEsc.transform);

        var fondo = Sprite("Fondo", "fondo_isla", -10); fondo.transform.SetParent(gEsc.transform);

        GameObject Inst(string clave, Vector3 pos, Transform padre, string nombre = null)
        {
            var go = (GameObject)PrefabUtility.InstantiatePrefab(p[clave]);
            go.transform.SetParent(padre); go.transform.position = pos;
            if (nombre != null) go.name = nombre;
            return go;
        }

        // Plataformas
        var suelo = Inst("Plataforma", new Vector3(-3.5f, -4.6f, 0), gEsc.transform, "Suelo_Muelle");
        suelo.transform.localScale = new Vector3(6.5f, 1, 1);
        var suelo2 = Inst("Plataforma", new Vector3(6.5f, -4.6f, 0), gEsc.transform, "Suelo_Faro");
        suelo2.transform.localScale = new Vector3(3.5f, 1, 1);
        Inst("Plataforma", new Vector3(-6f, -1.8f, 0), gEsc.transform, "Plataforma_1").transform.localScale = new Vector3(1.5f, 1, 1);
        Inst("Plataforma", new Vector3(-1.5f, -0.6f, 0), gEsc.transform, "Plataforma_2").transform.localScale = new Vector3(1.5f, 1, 1);
        Inst("Plataforma", new Vector3(2.8f, -2.2f, 0), gEsc.transform, "Plataforma_3").transform.localScale = new Vector3(1.5f, 1, 1);

        // Entidades
        var nara = Inst("Nara", new Vector3(-7.5f, -3.5f, 0), gEnt.transform);
        var sombra = Inst("SombraNiebla", new Vector3(-2f, -3.7f, 0), gEnt.transform);
        var a = new GameObject("PatrullaA"); a.transform.SetParent(gEnt.transform); a.transform.position = new Vector3(-4.5f, -3.7f, 0);
        var b = new GameObject("PatrullaB"); b.transform.SetParent(gEnt.transform); b.transform.position = new Vector3(0.5f, -3.7f, 0);
        Set(sombra.GetComponent<Enemigo>(), "puntoA", a.transform);
        Set(sombra.GetComponent<Enemigo>(), "puntoB", b.transform);

        var puerta = Inst("CompuertaFaro", new Vector3(5f, -3.35f, 0), gObj.transform);

        var posiciones = new[]
        {
            new Vector3(-6f, -0.9f, 0), new Vector3(-1.5f, 0.3f, 0), new Vector3(2.8f, -1.3f, 0),
            new Vector3(-3.8f, -3.6f, 0), new Vector3(7.8f, -3.6f, 0),
        };
        for (int i = 0; i < fragmentos; i++)
            Inst("FragmentoLuz", posiciones[i], gObj.transform, $"FragmentoLuz_{i + 1}");

        var musica = new GameObject("MusicaAmbiente"); musica.transform.SetParent(gSis.transform);
        var au = musica.AddComponent<AudioSource>(); au.clip = A("musica_olas_loop"); au.loop = true; au.playOnAwake = true; au.volume = 0.4f;

        // UI
        var canvasGo = new GameObject("Canvas", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        canvasGo.transform.SetParent(gSis.transform);
        canvasGo.GetComponent<Canvas>().renderMode = RenderMode.ScreenSpaceOverlay;
        var scaler = canvasGo.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);
        scaler.matchWidthOrHeight = 0.5f;

        var evs = new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
        evs.transform.SetParent(gSis.transform);

        var recursos = new TMP_DefaultControls.Resources
        {
            standard = AssetDatabase.GetBuiltinExtraResource<Sprite>("UI/Skin/UISprite.psd"),
            background = AssetDatabase.GetBuiltinExtraResource<Sprite>("UI/Skin/Background.psd"),
        };
        var boton = TMP_DefaultControls.CreateButton(recursos);
        boton.name = "BotonCompuerta";
        boton.transform.SetParent(canvasGo.transform, false);
        var rtB = (RectTransform)boton.transform;
        rtB.anchorMin = rtB.anchorMax = rtB.pivot = new Vector2(1, 0);
        rtB.anchoredPosition = new Vector2(-40, 40); rtB.sizeDelta = new Vector2(360, 90);
        var txtBoton = boton.GetComponentInChildren<TMP_Text>();
        txtBoton.text = "Abrir compuerta"; txtBoton.fontSize = 34; txtBoton.color = new Color(0.12f, 0.16f, 0.3f);
        var btn = boton.GetComponent<Button>();
        UnityEventTools.AddPersistentListener(btn.onClick, puerta.GetComponent<Puerta>().Interactuar);

        var txtPuntaje = Texto(canvasGo.transform, "TextoPuntaje", "Luz: 0", new Vector2(0, 1), new Vector2(40, -30), 48, TextAlignmentOptions.TopLeft);
        var txtMensaje = Texto(canvasGo.transform, "TextoMensaje", "", new Vector2(0.5f, 1), new Vector2(0, -40), 54, TextAlignmentOptions.Top);
        Texto(canvasGo.transform, "TextoControles", "Flechas/A-D: mover   Espacio: saltar   F: destello",
              new Vector2(0, 0), new Vector2(40, 40), 30, TextAlignmentOptions.BottomLeft);

        var gestorUI = canvasGo.AddComponent<GestorUI>();
        Set(gestorUI, "botonPuerta", btn);
        Set(gestorUI, "textoBoton", txtBoton);
        Set(gestorUI, "textoPuntaje", txtPuntaje);
        Set(gestorUI, "textoMensaje", txtMensaje);
        Set(gestorUI, "puerta", puerta.GetComponent<Puerta>());

        var gestor = new GameObject("GestorJuego"); gestor.transform.SetParent(gSis.transform);
        Set(gestor.AddComponent<GestorJuego>(), "interfaz", gestorUI);

        EditorSceneManager.SaveScene(esc, ruta);
    }

    // ---------------------------------------------------------------- Builds
    public static void BuildWebGL()
    {
        PlayerSettings.WebGL.compressionFormat = WebGLCompressionFormat.Disabled;
        PlayerSettings.WebGL.decompressionFallback = false;
        var r = BuildPipeline.BuildPlayer(new[] { ESC + "/Nivel_01.unity" }, "Builds/WebGL", BuildTarget.WebGL, BuildOptions.None);
        Debug.Log("[ConstructorFaro] WebGL: " + r.summary.result + " " + r.summary.totalSize);
    }

    public static void BuildWindows()
    {
        var r = BuildPipeline.BuildPlayer(new[] { ESC + "/Nivel_01.unity" }, "Builds/Windows/FaroDeEcos2D.exe",
                                          BuildTarget.StandaloneWindows64, BuildOptions.None);
        Debug.Log("[ConstructorFaro] Windows: " + r.summary.result + " " + r.summary.totalSize);
    }
}
#endif
