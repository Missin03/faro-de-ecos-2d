using UnityEngine;

/// <summary>
/// Destello de luz que lanza Nara. Avanza en línea recta y daña al primer IDaniable que toca.
/// </summary>
[RequireComponent(typeof(Rigidbody2D), typeof(Collider2D))]
public class Proyectil : MonoBehaviour
{
    [SerializeField] private float velocidad = 10f;
    [SerializeField] private int danio = 1;
    [SerializeField] private float vida = 2f;

    private GameObject duenio;

    public void Lanzar(int direccion, GameObject quienDispara)
    {
        duenio = quienDispara;
        GetComponent<Rigidbody2D>().linearVelocity = new Vector2(direccion * velocidad, 0f);
        Destroy(gameObject, vida);
    }

    private void OnTriggerEnter2D(Collider2D otro)
    {
        if (otro.gameObject == duenio) return;
        IDaniable objetivo = otro.GetComponent<IDaniable>();
        if (objetivo != null)
        {
            objetivo.RecibirDanio(danio);
            Destroy(gameObject);
        }
    }
}
